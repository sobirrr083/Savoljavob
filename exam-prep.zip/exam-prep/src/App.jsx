import { useState, useCallback } from 'react';
import { parseExamFile } from './utils/parser.js';
import FileUpload from './components/FileUpload.jsx';
import Sidebar from './components/Sidebar.jsx';
import ReadingMode from './components/ReadingMode.jsx';
import WritingMode from './components/WritingMode.jsx';
import VariantMode from './components/VariantMode.jsx';
import TicketMode from './components/TicketMode.jsx';
import Settings from './components/Settings.jsx';

const DEFAULT_SETTINGS = {
  perTicket: 10,
  shuffleQuestions: false,
  shuffleOptions: true,
  showHints: true,
  autoNext: false,
};

export default function App() {
  const [questions, setQuestions] = useState([]);
  const [fileName, setFileName] = useState('');
  const [mode, setMode] = useState('home');
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const handleFile = useCallback((text, name) => {
    const parsed = parseExamFile(text);
    setQuestions(parsed);
    setFileName(name);
    setMode('read');
  }, []);

  const reset = () => {
    setQuestions([]);
    setFileName('');
    setMode('home');
  };

  if (mode === 'home') {
    return <FileUpload onFile={handleFile} />;
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
      <Sidebar
        mode={mode}
        setMode={setMode}
        fileName={fileName}
        total={questions.length}
        onReset={reset}
        onSettings={() => setSettingsOpen(true)}
      />
      <main style={{ flex: 1, minWidth: 0, padding: '32px 24px', overflowY: 'auto' }}>
        {mode === 'read' && <ReadingMode questions={questions} settings={settings} />}
        {mode === 'write' && <WritingMode questions={questions} settings={settings} />}
        {mode === 'variant' && <VariantMode questions={questions} settings={settings} />}
        {mode === 'ticket' && <TicketMode questions={questions} settings={settings} />}
      </main>
      {settingsOpen && (
        <Settings
          settings={settings}
          onChange={setSettings}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
