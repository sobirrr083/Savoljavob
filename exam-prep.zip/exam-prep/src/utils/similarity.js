/**
 * Text similarity scoring without AI.
 * Uses multiple strategies and combines them for a robust score.
 */

function normalize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\u0400-\u04FF\u00C0-\u024F\s]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokenize(text) {
  return normalize(text).split(' ').filter(t => t.length > 1);
}

function jaccardSimilarity(a, b) {
  const setA = new Set(a);
  const setB = new Set(b);
  const intersection = [...setA].filter(x => setB.has(x)).length;
  const union = new Set([...setA, ...setB]).size;
  return union === 0 ? 0 : intersection / union;
}

function cosineSimilarity(tokensA, tokensB) {
  const freq = (tokens) => {
    const map = {};
    for (const t of tokens) map[t] = (map[t] || 0) + 1;
    return map;
  };
  const fA = freq(tokensA);
  const fB = freq(tokensB);
  const allKeys = new Set([...Object.keys(fA), ...Object.keys(fB)]);
  let dot = 0, normA = 0, normB = 0;
  for (const k of allKeys) {
    const a = fA[k] || 0;
    const b = fB[k] || 0;
    dot += a * b;
    normA += a * a;
    normB += b * b;
  }
  return normA === 0 || normB === 0 ? 0 : dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

function keywordCoverage(userTokens, correctTokens) {
  // How many important words from correct answer appear in user's answer
  const stop = new Set(['va', 'bu', 'ham', 'bilan', 'uchun', 'da', 'ni', 'ga', 'dan', 'ning', 'dir',
    'is', 'the', 'a', 'an', 'of', 'in', 'to', 'and', 'or', 'for', 'on', 'at',
    'это', 'и', 'в', 'на', 'с', 'по', 'к', 'от', 'для']);
  const keywords = correctTokens.filter(t => !stop.has(t) && t.length > 2);
  if (keywords.length === 0) return 0;
  const userSet = new Set(userTokens);
  const found = keywords.filter(k => userSet.has(k) || 
    [...userSet].some(u => u.includes(k) || k.includes(u))).length;
  return found / keywords.length;
}

function longestCommonSubsequenceRatio(a, b) {
  // Char-level LCS for short strings
  if (a.length > 200 || b.length > 200) return 0;
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1] + 1 : Math.max(dp[i-1][j], dp[i][j-1]);
  return (2 * dp[m][n]) / (m + n);
}

export function scoreSimilarity(userAnswer, correctAnswer) {
  if (!userAnswer || !correctAnswer) return { score: 0, grade: 'F', feedback: [] };
  
  const userN = normalize(userAnswer);
  const correctN = normalize(correctAnswer);
  const userTokens = tokenize(userAnswer);
  const correctTokens = tokenize(correctAnswer);

  const jaccard = jaccardSimilarity(userTokens, correctTokens);
  const cosine = cosineSimilarity(userTokens, correctTokens);
  const coverage = keywordCoverage(userTokens, correctTokens);
  const lcs = longestCommonSubsequenceRatio(
    userN.slice(0, 150), 
    correctN.slice(0, 150)
  );

  // Weighted combination
  const raw = jaccard * 0.25 + cosine * 0.30 + coverage * 0.30 + lcs * 0.15;
  const score = Math.min(100, Math.round(raw * 100));

  const feedback = [];
  if (coverage < 0.3) feedback.push('Asosiy atamalar yetishmaydi');
  if (userTokens.length < correctTokens.length * 0.4) feedback.push("Javob qisqaroq ko'rinadi");
  if (jaccard > 0.6) feedback.push('Kalit so\'zlar mos');
  if (score >= 80) feedback.push('Ajoyib javob!');

  let grade = 'F';
  if (score >= 90) grade = 'A';
  else if (score >= 75) grade = 'B';
  else if (score >= 55) grade = 'C';
  else if (score >= 35) grade = 'D';

  return { score, grade, feedback, details: { jaccard, cosine, coverage, lcs } };
}

export function gradeColor(grade) {
  const map = { A: '#4ade80', B: '#a3e635', C: '#facc15', D: '#fb923c', F: '#f87171' };
  return map[grade] || '#f87171';
}

export function gradeLabel(score) {
  if (score >= 90) return "A'lo";
  if (score >= 75) return "Yaxshi";
  if (score >= 55) return "Qoniqarli";
  if (score >= 35) return "Past";
  return "Noto'g'ri";
}
