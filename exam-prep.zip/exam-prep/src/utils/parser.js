/**
 * Parses Uzbek exam .txt files into structured question objects.
 * Supports formats:
 * - ANSWER: A (correct answer always appears as option A, rotated)
 * - +/- markers
 * - Bold markers via *text* or uppercase
 * - Standard A) B) C) D) format
 */

export function parseExamFile(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  const questions = [];
  let current = null;
  let optionBuffer = [];

  const optionRegex = /^([A-Ga-g])[.):\s]\s*(.+)/;
  const questionNumRegex = /^(\d+)[.):\s]\s*(.+)/;
  const answerRegex = /^(?:ANSWER|JAVOB|TO'G'RI|TOGRI)\s*[:=]\s*([A-Ga-g])/i;
  const plusMarker = /^\+\s*(.+)/;
  const minusMarker = /^-\s*(.+)/;

  const flush = () => {
    if (!current) return;
    if (optionBuffer.length > 0) {
      current.options = optionBuffer;
      optionBuffer = [];
    }
    if (current.question && current.options && current.options.length >= 2) {
      questions.push(current);
    }
    current = null;
  };

  let inPlusMinusBlock = false;
  let pmOptions = [];
  let pmCorrect = null;
  let pmQuestion = null;
  let pmLineIdx = -1;

  // Detect +/- format
  const hasPlusMinus = lines.some(l => /^\+/.test(l));

  if (hasPlusMinus) {
    return parsePlusMinus(lines);
  }

  // Standard format
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const answerMatch = line.match(answerRegex);
    if (answerMatch) {
      if (current) {
        current.correctIndex = answerMatch[1].toUpperCase().charCodeAt(0) - 65;
        if (optionBuffer.length > 0) {
          current.options = optionBuffer;
          optionBuffer = [];
        }
        flush();
      }
      continue;
    }

    const optMatch = line.match(optionRegex);
    if (optMatch) {
      const letter = optMatch[1].toUpperCase();
      const text = optMatch[2].trim();
      const idx = letter.charCodeAt(0) - 65;
      optionBuffer[idx] = text;
      continue;
    }

    const qMatch = line.match(questionNumRegex);
    if (qMatch) {
      flush();
      optionBuffer = [];
      current = {
        id: questions.length,
        number: parseInt(qMatch[1]),
        question: qMatch[2].trim(),
        options: [],
        correctIndex: 0,
        raw: line,
      };
      continue;
    }

    // Line might be continuation of question or a question without number
    if (current && optionBuffer.length === 0 && !optMatch) {
      // Possible multi-line question
      if (line.length > 5 && !/^\d+[.)]/.test(line)) {
        current.question += ' ' + line;
      }
    } else if (!current && line.length > 10) {
      // Standalone question without number
      flush();
      optionBuffer = [];
      current = {
        id: questions.length,
        number: questions.length + 1,
        question: line,
        options: [],
        correctIndex: 0,
        raw: line,
      };
    }
  }

  flush();

  return questions.map((q, i) => ({
    ...q,
    id: i,
    number: q.number || i + 1,
    options: q.options.filter(Boolean),
    correctIndex: Math.max(0, Math.min(q.correctIndex, (q.options.filter(Boolean).length || 1) - 1)),
  })).filter(q => q.options.length >= 2);
}

function parsePlusMinus(lines) {
  const questions = [];
  let currentQ = null;
  let opts = [];
  let correctIdx = null;

  const flushQ = () => {
    if (currentQ && opts.length >= 2) {
      questions.push({
        id: questions.length,
        number: questions.length + 1,
        question: currentQ,
        options: opts,
        correctIndex: correctIdx ?? 0,
      });
    }
    opts = [];
    correctIdx = null;
    currentQ = null;
  };

  const qNum = /^(\d+)[.):\s]\s*(.+)/;

  for (const line of lines) {
    const qm = line.match(qNum);
    if (qm) {
      flushQ();
      currentQ = qm[2].trim();
      continue;
    }
    const pm = line.match(/^([+\-])\s*(.+)/);
    if (pm && currentQ) {
      if (pm[1] === '+') correctIdx = opts.length;
      opts.push(pm[2].trim());
      continue;
    }
    if (currentQ && opts.length === 0) {
      currentQ += ' ' + line;
    }
  }
  flushQ();
  return questions;
}

export function groupIntoTickets(questions, perTicket = 10) {
  const tickets = [];
  for (let i = 0; i < questions.length; i += perTicket) {
    tickets.push({
      id: Math.floor(i / perTicket),
      number: Math.floor(i / perTicket) + 1,
      questions: questions.slice(i, i + perTicket),
    });
  }
  return tickets;
}

export function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function shuffleOptions(question) {
  const indices = question.options.map((_, i) => i);
  const shuffled = shuffleArray(indices);
  return {
    ...question,
    options: shuffled.map(i => question.options[i]),
    correctIndex: shuffled.indexOf(question.correctIndex),
    _shuffleMap: shuffled,
  };
}
