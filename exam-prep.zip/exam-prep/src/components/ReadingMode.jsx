import { useState, useMemo } from 'react';

const OPTION_LABELS = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
const OPTION_COLORS = ['var(--green)', 'var(--blue)', 'var(--amber)', '#c084fc', '#22d3ee', '#fb7185'];

export default function ReadingMode({ questions }) {
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState(new Set());
  const [showAll, setShowAll] = useState(false);

  const filtered = useMemo(() => {
    if (!search.trim()) return questions;
    const q = search.toLowerCase();
    return questions.filter(item =>
      item.question.toLowerCase().includes(q) ||
      item.options.some(o => o.toLowerCase().includes(q))
    );
  }, [questions, search]);

  const toggleAll = () => {
    if (showAll) { setExpanded(new Set()); setShowAll(false); }
    else { setExpanded(new Set(filtered.map(q => q.id))); setShowAll(true); }
  };

  const toggle = (id) => {
    setExpanded(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  return (
    <div style={{ maxWidth: 780, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, marginBottom: 6 }}>
          Erkin O'qish
        </h1>
        <p style={{ color: 'var(--text2)', fontSize: 14 }}>
          {questions.length} ta savol — istalganini kengaytiring
        </p>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text3)', fontSize: 14 }}>🔍</span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Qidirish..."
            style={{
              width: '100%',
              padding: '10px 12px 10px 36px',
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: 8,
              color: 'var(--text)',
              fontSize: 14,
              outline: 'none',
              transition: 'border 0.2s',
            }}
            onFocus={e => e.target.style.borderColor = 'var(--gold)'}
            onBlur={e => e.target.style.borderColor = 'var(--border)'}
          />
        </div>
        <button
          onClick={toggleAll}
          style={{
            padding: '10px 18px',
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: showAll ? 'var(--gold-dim)' : 'var(--surface)',
            color: showAll ? 'var(--gold)' : 'var(--text2)',
            fontSize: 13,
            fontWeight: 500,
            cursor: 'pointer',
            whiteSpace: 'nowrap',
          }}
        >
          {showAll ? '↑ Barchasini yig\'ish' : '↓ Barchasini ochish'}
        </button>
      </div>

      {/* Stats */}
      {search && (
        <div style={{ marginBottom: 16, fontSize: 13, color: 'var(--text3)' }}>
          {filtered.length} ta natija topildi
        </div>
      )}

      {/* Question list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {filtered.map((q, idx) => {
          const open = expanded.has(q.id);
          return (
            <div
              key={q.id}
              style={{
                background: 'var(--surface)',
                border: `1px solid ${open ? 'rgba(232,184,75,0.25)' : 'var(--border)'}`,
                borderRadius: 'var(--radius)',
                overflow: 'hidden',
                transition: 'border-color 0.2s',
              }}
            >
              <button
                onClick={() => toggle(q.id)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: 14,
                  padding: '16px 20px',
                  background: 'transparent',
                  cursor: 'pointer',
                  textAlign: 'left',
                  color: 'var(--text)',
                }}
              >
                <span style={{
                  flexShrink: 0,
                  width: 28,
                  height: 28,
                  borderRadius: 8,
                  background: open ? 'var(--gold)' : 'var(--bg3)',
                  color: open ? '#0d0f14' : 'var(--text2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 11,
                  fontWeight: 700,
                  transition: 'all 0.2s',
                }}>
                  {q.number}
                </span>
                <span style={{ flex: 1, fontSize: 15, lineHeight: 1.55, paddingTop: 4 }}>
                  {q.question}
                </span>
                <span style={{
                  fontSize: 12,
                  color: open ? 'var(--gold)' : 'var(--text3)',
                  transform: open ? 'rotate(180deg)' : 'none',
                  transition: 'transform 0.2s',
                  marginTop: 6,
                  flexShrink: 0,
                }}>▼</span>
              </button>

              {open && (
                <div style={{ padding: '0 20px 20px', animation: 'fadeIn 0.2s ease' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {q.options.map((opt, i) => {
                      const isCorrect = i === q.correctIndex;
                      return (
                        <div key={i} style={{
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: 10,
                          padding: '10px 14px',
                          borderRadius: 8,
                          background: isCorrect ? 'var(--green-bg)' : 'var(--bg3)',
                          border: `1px solid ${isCorrect ? 'rgba(74,222,128,0.25)' : 'transparent'}`,
                          transition: 'all 0.15s',
                        }}>
                          <span style={{
                            flexShrink: 0,
                            width: 24,
                            height: 24,
                            borderRadius: 6,
                            background: isCorrect ? 'var(--green)' : 'var(--bg4)',
                            color: isCorrect ? '#0d0f14' : 'var(--text3)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: 11,
                            fontWeight: 700,
                          }}>
                            {OPTION_LABELS[i]}
                          </span>
                          <span style={{ fontSize: 14, color: isCorrect ? 'var(--text)' : 'var(--text2)', lineHeight: 1.5, paddingTop: 2 }}>
                            {opt}
                          </span>
                          {isCorrect && (
                            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--green)', fontWeight: 600, flexShrink: 0 }}>
                              ✓ To'g'ri
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text3)' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
          <div>Hech narsa topilmadi</div>
        </div>
      )}
    </div>
  );
}
