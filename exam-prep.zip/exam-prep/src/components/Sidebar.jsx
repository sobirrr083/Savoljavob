const MODES = [
  { id: 'read',    icon: '📖', label: "O'qish",   desc: 'Barchasi' },
  { id: 'write',   icon: '✍️', label: 'Yozma',    desc: 'Baholash' },
  { id: 'variant', icon: '📋', label: 'Variant',  desc: 'A/B/C/D' },
  { id: 'ticket',  icon: '🎫', label: 'Bilet',    desc: 'Random' },
];

export default function Sidebar({ mode, setMode, fileName, total, onReset, onSettings }) {
  return (
    <aside style={{
      width: 220,
      flexShrink: 0,
      background: 'var(--bg2)',
      borderRight: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px 0',
      position: 'sticky',
      top: 0,
      height: '100vh',
      overflowY: 'auto',
    }}>
      {/* Logo */}
      <div style={{ padding: '0 20px 24px', borderBottom: '1px solid var(--border)' }}>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: 20,
          fontWeight: 700,
          color: 'var(--gold)',
          letterSpacing: '-0.02em',
        }}>
          ImtihonPro
        </div>
        {fileName && (
          <div style={{
            fontSize: 11,
            color: 'var(--text3)',
            marginTop: 4,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }} title={fileName}>
            📄 {fileName}
          </div>
        )}
        {total > 0 && (
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 4,
            marginTop: 8,
            background: 'var(--gold-dim)',
            borderRadius: 6,
            padding: '2px 8px',
            fontSize: 11,
            color: 'var(--gold)',
            fontWeight: 500,
          }}>
            {total} ta savol
          </div>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '16px 12px' }}>
        <div style={{ fontSize: 10, color: 'var(--text3)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0 8px', marginBottom: 8 }}>
          Rejimlar
        </div>
        {MODES.map(m => {
          const active = mode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '10px 12px',
                borderRadius: 10,
                fontSize: 14,
                fontWeight: active ? 600 : 400,
                color: active ? 'var(--gold)' : 'var(--text2)',
                background: active ? 'var(--gold-dim)' : 'transparent',
                border: active ? '1px solid rgba(232,184,75,0.2)' : '1px solid transparent',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.15s',
                marginBottom: 4,
              }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--bg3)'; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
            >
              <span style={{ fontSize: 18, flexShrink: 0 }}>{m.icon}</span>
              <div>
                <div>{m.label}</div>
                <div style={{ fontSize: 11, color: active ? 'var(--gold)' : 'var(--text3)', opacity: 0.8 }}>{m.desc}</div>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Bottom actions */}
      <div style={{ padding: '16px 12px', borderTop: '1px solid var(--border)', display: 'flex', flexDirection: 'column', gap: 6 }}>
        <button
          onClick={onSettings}
          style={{
            width: '100%',
            padding: '9px 12px',
            borderRadius: 8,
            fontSize: 13,
            color: 'var(--text2)',
            background: 'transparent',
            border: '1px solid var(--border)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--border2)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
        >
          ⚙️ Sozlamalar
        </button>
        <button
          onClick={onReset}
          style={{
            width: '100%',
            padding: '9px 12px',
            borderRadius: 8,
            fontSize: 13,
            color: 'var(--red)',
            background: 'transparent',
            border: '1px solid rgba(248,113,113,0.2)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'var(--red-bg)'}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
        >
          ↩ Yangi fayl
        </button>
      </div>
    </aside>
  );
}
