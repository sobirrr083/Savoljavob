import { useState, useMemo } from 'react';
import { groupIntoTickets, shuffleArray, shuffleOptions } from '../utils/parser.js';

const OPTION_LABELS = ['A', 'B', 'C', 'D', 'E', 'F'];
const OPTION_COLORS = ['#60a5fa', '#4ade80', '#fb923c', '#c084fc', '#22d3ee', '#fb7185'];

export default function TicketMode({ questions, settings }) {
  const [ticketIdx, setTicketIdx] = useState(null);
  const [qIdx, setQIdx] = useState(0);
  const [answered, setAnswered] = useState({});
  const [selected, setSelected] = useState(null);
  const [finished, setFinished] = useState(false);
  const [randomTicket, setRandomTicket] = useState(false);

  const tickets = useMemo(() => {
    const base = groupIntoTickets(questions, settings.perTicket);
    if (!settings.shuffleQuestions) return base;
    return base.map(t => ({
      ...t,
      questions: shuffleArray(t.questions),
    }));
  }, [questions, settings.perTicket, settings.shuffleQuestions]);

  const currentTicket = useMemo(() => {
    if (ticketIdx === null) return null;
    const t = tickets[ticketIdx];
    if (!t) return null;
    return {
      ...t,
      questions: settings.shuffleOptions
        ? t.questions.map(q => shuffleOptions(q))
        : t.questions,
    };
  }, [tickets, ticketIdx, settings.shuffleOptions]);

  const q = currentTicket?.questions[qIdx];

  const handleSelect = (i) => {
    if (selected !== null) return;
    setSelected(i);
    const correct = i === q.correctIndex;
    setAnswered(prev => ({ ...prev, [qIdx]: { selected: i, correct } }));
  };

  const handleNext = () => {
    const total = currentTicket.questions.length;
    if (qIdx < total - 1) {
      setQIdx(q => q + 1);
      setSelected(answered[qIdx + 1]?.selected ?? null);
    } else {
      setFinished(true);
    }
  };

  const handlePrev = () => {
    if (qIdx > 0) {
      setQIdx(q => q - 1);
      setSelected(answered[qIdx - 1]?.selected ?? null);
    }
  };

  const startTicket = (idx) => {
    setTicketIdx(idx);
    setQIdx(0);
    setAnswered({});
    setSelected(null);
    setFinished(false);
  };

  const startRandom = () => {
    const idx = Math.floor(Math.random() * tickets.length);
    setRandomTicket(true);
    startTicket(idx);
  };

  const backToList = () => {
    setTicketIdx(null);
    setFinished(false);
    setRandomTicket(false);
  };

  // ── Ticket list ──────────────────────────────────────────────────────────
  if (ticketIdx === null) {
    return (
      <div style={{ maxWidth: 780, margin: '0 auto' }} className="fade-in">
        <div style={{ marginBottom: 32 }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, marginBottom: 6 }}>
            Bilet Rejimi
          </h1>
          <p style={{ color: 'var(--text2)', fontSize: 14 }}>
            {tickets.length} ta bilet · har birida {settings.perTicket} ta savol
          </p>
        </div>

        {/* Random start */}
        <button
          onClick={startRandom}
          style={{
            width: '100%',
            padding: '18px',
            borderRadius: 'var(--radius-lg)',
            background: 'linear-gradient(135deg, var(--gold-dim), rgba(96,165,250,0.1))',
            border: '1px solid rgba(232,184,75,0.3)',
            color: 'var(--gold)',
            fontSize: 15,
            fontWeight: 600,
            cursor: 'pointer',
            marginBottom: 24,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 10,
            transition: 'all 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'linear-gradient(135deg, rgba(232,184,75,0.2), rgba(96,165,250,0.15))'}
          onMouseLeave={e => e.currentTarget.style.background = 'linear-gradient(135deg, var(--gold-dim), rgba(96,165,250,0.1))'}
        >
          🎲 Tasodifiy bilet boshlash
        </button>

        {/* Grid of tickets */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
          gap: 10,
        }}>
          {tickets.map((t, i) => (
            <button
              key={t.id}
              onClick={() => startTicket(i)}
              style={{
                padding: '18px 12px',
                borderRadius: 'var(--radius)',
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                cursor: 'pointer',
                textAlign: 'center',
                transition: 'all 0.18s',
                color: 'var(--text)',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--gold)';
                e.currentTarget.style.background = 'var(--gold-dim)';
                e.currentTarget.style.color = 'var(--gold)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)';
                e.currentTarget.style.background = 'var(--surface)';
                e.currentTarget.style.color = 'var(--text)';
              }}
            >
              <div style={{ fontSize: 24, marginBottom: 6 }}>🎫</div>
              <div style={{ fontWeight: 700, fontSize: 16 }}>{t.number}</div>
              <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>
                {t.questions.length} savol
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // ── Finished screen ──────────────────────────────────────────────────────
  if (finished) {
    const total = currentTicket.questions.length;
    const correctCount = Object.values(answered).filter(a => a.correct).length;
    const pct = Math.round((correctCount / total) * 100);
    const grade = pct >= 86 ? '5' : pct >= 71 ? '4' : pct >= 56 ? '3' : '2';
    const gradeColors = { '5': 'var(--green)', '4': '#a3e635', '3': 'var(--amber)', '2': 'var(--red)' };
    const gradeColor = gradeColors[grade];

    return (
      <div style={{ maxWidth: 560, margin: '0 auto', textAlign: 'center' }} className="scale-in">
        <div style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-lg)',
          padding: '48px 32px',
        }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>
            {pct >= 70 ? '🎉' : pct >= 50 ? '📚' : '💪'}
          </div>
          <div style={{
            fontFamily: 'var(--font-display)',
            fontSize: 48,
            fontWeight: 800,
            color: gradeColor,
            marginBottom: 8,
            lineHeight: 1,
          }}>
            {pct}%
          </div>
          <div style={{ fontSize: 18, color: 'var(--text2)', marginBottom: 4 }}>
            {correctCount}/{total} to'g'ri
          </div>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            background: `${gradeColor}22`,
            border: `1px solid ${gradeColor}44`,
            borderRadius: 8,
            padding: '6px 16px',
            marginTop: 8,
            marginBottom: 28,
          }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: gradeColor }}>{grade}</span>
            <span style={{ fontSize: 13, color: gradeColor }}>baho</span>
          </div>

          {/* Per-question summary */}
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 28 }}>
            {currentTicket.questions.map((q, i) => {
              const ans = answered[i];
              const correct = ans?.correct;
              return (
                <div key={i} style={{
                  width: 32, height: 32, borderRadius: 7,
                  background: !ans ? 'var(--bg3)' : correct ? 'var(--green-bg)' : 'var(--red-bg)',
                  border: `1px solid ${!ans ? 'transparent' : correct ? 'rgba(74,222,128,0.3)' : 'rgba(248,113,113,0.3)'}`,
                  color: !ans ? 'var(--text3)' : correct ? 'var(--green)' : 'var(--red)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700,
                }}>
                  {i + 1}
                </div>
              );
            })}
          </div>

          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              onClick={() => startTicket(ticketIdx)}
              style={{
                padding: '11px 22px', borderRadius: 8,
                background: 'var(--gold)', color: '#0d0f14',
                fontSize: 14, fontWeight: 600, cursor: 'pointer', border: 'none',
              }}
            >
              🔁 Qayta yechish
            </button>
            <button
              onClick={startRandom}
              style={{
                padding: '11px 22px', borderRadius: 8,
                border: '1px solid var(--border)', background: 'transparent',
                color: 'var(--text2)', fontSize: 14, cursor: 'pointer',
              }}
            >
              🎲 Yangi bilet
            </button>
            <button
              onClick={backToList}
              style={{
                padding: '11px 22px', borderRadius: 8,
                border: '1px solid var(--border)', background: 'transparent',
                color: 'var(--text2)', fontSize: 14, cursor: 'pointer',
              }}
            >
              📋 Ro'yxat
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Question view ────────────────────────────────────────────────────────
  if (!q) return null;
  const total = currentTicket.questions.length;
  const hasAnswered = selected !== null;
  const isCorrect = hasAnswered && selected === q.correctIndex;
  const progress = (Object.keys(answered).length / total);

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button
              onClick={backToList}
              style={{
                padding: '6px 12px', borderRadius: 6,
                border: '1px solid var(--border)', background: 'transparent',
                color: 'var(--text3)', fontSize: 12, cursor: 'pointer',
              }}
            >← Ro'yxat</button>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: 'var(--gold-dim)', border: '1px solid rgba(232,184,75,0.25)',
              borderRadius: 8, padding: '4px 12px',
              fontSize: 13, fontWeight: 600, color: 'var(--gold)',
            }}>
              🎫 Bilet {currentTicket.number}
              {randomTicket && <span style={{ fontSize: 10, opacity: 0.7 }}>(random)</span>}
            </div>
          </div>
        </div>
        <div style={{ fontSize: 13, color: 'var(--text2)' }}>
          {qIdx + 1} / {total}
        </div>
      </div>

      {/* Progress */}
      <div style={{ height: 4, background: 'var(--surface)', borderRadius: 2, marginBottom: 20, overflow: 'hidden' }}>
        <div style={{
          height: '100%',
          background: 'linear-gradient(90deg, var(--gold), var(--gold2))',
          width: `${progress * 100}%`,
          borderRadius: 2,
          transition: 'width 0.3s ease',
        }} />
      </div>

      {/* Mini navigation dots */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, flexWrap: 'wrap' }}>
        {currentTicket.questions.map((_, i) => {
          const ans = answered[i];
          const isCur = i === qIdx;
          return (
            <button
              key={i}
              onClick={() => { setQIdx(i); setSelected(answered[i]?.selected ?? null); }}
              style={{
                width: 26, height: 26, borderRadius: 6,
                fontSize: 10, fontWeight: 600,
                background: isCur ? 'var(--gold)' : ans?.correct ? 'var(--green-bg)' : ans ? 'var(--red-bg)' : 'var(--bg3)',
                color: isCur ? '#0d0f14' : ans?.correct ? 'var(--green)' : ans ? 'var(--red)' : 'var(--text3)',
                border: `1px solid ${isCur ? 'var(--gold)' : 'transparent'}`,
                cursor: 'pointer', transition: 'all 0.15s',
              }}
            >{i + 1}</button>
          );
        })}
      </div>

      {/* Question card */}
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        padding: '28px',
        marginBottom: 16,
        animation: 'scaleIn 0.2s ease',
      }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
          <div style={{
            flexShrink: 0, width: 36, height: 36, borderRadius: 10,
            background: 'var(--gold-dim)', border: '1px solid rgba(232,184,75,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, color: 'var(--gold)', fontSize: 13,
          }}>
            {qIdx + 1}
          </div>
          <p style={{ fontSize: 16, lineHeight: 1.6, paddingTop: 8, flex: 1 }}>{q.question}</p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {q.options.map((opt, i) => {
            const isSelected = selected === i;
            const isCor = i === q.correctIndex;
            let bg = 'var(--bg3)', border = 'var(--border)', lBg = 'var(--bg4)', lColor = OPTION_COLORS[i] || 'var(--text2)', tColor = 'var(--text2)';

            if (hasAnswered) {
              if (isCor) { bg = 'var(--green-bg)'; border = 'rgba(74,222,128,0.3)'; lBg = 'var(--green)'; lColor = '#0d0f14'; tColor = 'var(--text)'; }
              else if (isSelected) { bg = 'var(--red-bg)'; border = 'rgba(248,113,113,0.3)'; lBg = 'var(--red)'; lColor = '#fff'; tColor = 'var(--text)'; }
            }

            return (
              <button
                key={i}
                onClick={() => handleSelect(i)}
                disabled={hasAnswered}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: 12,
                  padding: '12px 16px', borderRadius: 10,
                  background: bg, border: `1px solid ${border}`,
                  cursor: hasAnswered ? 'default' : 'pointer',
                  textAlign: 'left', transition: 'all 0.18s',
                }}
                onMouseEnter={e => { if (!hasAnswered) { e.currentTarget.style.borderColor = OPTION_COLORS[i]; e.currentTarget.style.background = 'var(--bg4)'; } }}
                onMouseLeave={e => { if (!hasAnswered) { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--bg3)'; } }}
              >
                <span style={{
                  flexShrink: 0, width: 28, height: 28, borderRadius: 7,
                  background: lBg, color: lColor,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700, transition: 'all 0.18s',
                }}>{OPTION_LABELS[i]}</span>
                <span style={{ fontSize: 14, color: tColor, lineHeight: 1.55, paddingTop: 5, flex: 1 }}>{opt}</span>
                {hasAnswered && isCor && <span style={{ color: 'var(--green)', fontSize: 16, flexShrink: 0, paddingTop: 4 }}>✓</span>}
                {hasAnswered && isSelected && !isCor && <span style={{ color: 'var(--red)', fontSize: 16, flexShrink: 0, paddingTop: 4 }}>✗</span>}
              </button>
            );
          })}
        </div>

        {hasAnswered && (
          <div style={{
            marginTop: 14,
            padding: '11px 14px',
            borderRadius: 8,
            background: isCorrect ? 'var(--green-bg)' : 'var(--red-bg)',
            border: `1px solid ${isCorrect ? 'rgba(74,222,128,0.2)' : 'rgba(248,113,113,0.2)'}`,
            fontSize: 13,
            color: isCorrect ? 'var(--green)' : 'var(--red)',
            animation: 'fadeIn 0.2s ease',
          }}>
            {isCorrect
              ? '✓ Ajoyib! To\'g\'ri javob!'
              : `✗ Noto'g'ri. To'g'ri: ${OPTION_LABELS[q.correctIndex]}) ${q.options[q.correctIndex]}`}
          </div>
        )}
      </div>

      {/* Nav buttons */}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'space-between' }}>
        <button
          onClick={handlePrev}
          disabled={qIdx === 0}
          style={{
            padding: '11px 22px', borderRadius: 8,
            border: '1px solid var(--border)', background: 'transparent',
            color: 'var(--text2)', fontSize: 14,
            cursor: qIdx === 0 ? 'default' : 'pointer',
            opacity: qIdx === 0 ? 0.4 : 1,
          }}
        >← Oldingi</button>

        <button
          onClick={handleNext}
          style={{
            padding: '11px 28px', borderRadius: 8,
            background: 'var(--gold)', color: '#0d0f14',
            fontSize: 14, fontWeight: 600,
            cursor: 'pointer', border: 'none',
          }}
        >
          {qIdx === total - 1 ? '✓ Yakunlash' : 'Keyingi →'}
        </button>
      </div>
    </div>
  );
}
