import { useState, useMemo, useRef, useEffect } from 'react';
import { scoreSimilarity, gradeColor, gradeLabel } from '../utils/similarity.js';
import { shuffleArray } from '../utils/parser.js';

const OPTION_LABELS = ['A', 'B', 'C', 'D', 'E', 'F'];

export default function WritingMode({ questions, settings }) {
  const [order, setOrder] = useState(() =>
    settings.shuffleQuestions ? shuffleArray(questions.map((_, i) => i)) : questions.map((_, i) => i)
  );
  const [idx, setIdx] = useState(0);
  const [userText, setUserText] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState({});
  const textareaRef = useRef();
  const resultRef = useRef();

  const q = useMemo(() => questions[order[idx]], [questions, order, idx]);

  useEffect(() => {
    setUserText('');
    setRevealed(false);
    setResult(null);
    textareaRef.current?.focus();
  }, [idx]);

  const correctAnswer = q?.options[q.correctIndex] || '';

  const handleCheck = () => {
    if (!userText.trim()) return;
    const score = scoreSimilarity(userText, correctAnswer);
    setResult(score);
    setRevealed(true);
    setHistory(prev => ({ ...prev, [order[idx]]: score.grade }));
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 100);
  };

  const handleNext = () => {
    if (idx < order.length - 1) setIdx(i => i + 1);
  };

  const handlePrev = () => {
    if (idx > 0) setIdx(i => i - 1);
  };

  const handleReshuffle = () => {
    setOrder(shuffleArray(questions.map((_, i) => i)));
    setIdx(0);
    setHistory({});
  };

  const doneCount = Object.keys(history).length;
  const progress = doneCount / questions.length;

  if (!q) return null;

  const scoreColor = result ? gradeColor(result.grade) : 'var(--text)';
  const isGood = result && result.score >= 70;

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 28, gap: 16 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, marginBottom: 4 }}>
            Yozma Javob
          </h1>
          <p style={{ color: 'var(--text2)', fontSize: 13 }}>
            {doneCount}/{questions.length} javob berildi
          </p>
        </div>
        <button
          onClick={handleReshuffle}
          style={{
            padding: '8px 14px',
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'transparent',
            color: 'var(--text2)',
            fontSize: 12,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            whiteSpace: 'nowrap',
          }}
        >
          🔀 Aralashtirish
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ height: 4, background: 'var(--surface)', borderRadius: 2, marginBottom: 28, overflow: 'hidden' }}>
        <div style={{
          height: '100%',
          background: 'linear-gradient(90deg, var(--gold), var(--gold2))',
          width: `${progress * 100}%`,
          borderRadius: 2,
          transition: 'width 0.4s ease',
        }} />
      </div>

      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <button
          onClick={handlePrev}
          disabled={idx === 0}
          style={{
            padding: '8px 16px',
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'transparent',
            color: idx === 0 ? 'var(--text3)' : 'var(--text2)',
            fontSize: 13,
            cursor: idx === 0 ? 'default' : 'pointer',
            opacity: idx === 0 ? 0.4 : 1,
          }}
        >
          ← Oldingi
        </button>

        <div style={{
          display: 'flex',
          gap: 4,
          alignItems: 'center',
          flexWrap: 'wrap',
          justifyContent: 'center',
          maxWidth: 300,
        }}>
          {order.slice(Math.max(0, idx - 3), idx + 4).map((qi, i) => {
            const actualIdx = Math.max(0, idx - 3) + i;
            const grade = history[qi];
            const isCurrent = actualIdx === idx;
            return (
              <button
                key={qi}
                onClick={() => setIdx(actualIdx)}
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 6,
                  fontSize: 11,
                  fontWeight: 600,
                  background: isCurrent ? 'var(--gold)' : grade ? gradeColor(grade) + '33' : 'var(--bg3)',
                  color: isCurrent ? '#0d0f14' : grade ? gradeColor(grade) : 'var(--text3)',
                  border: isCurrent ? '2px solid var(--gold)' : '1px solid transparent',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                }}
              >
                {questions[qi]?.number || actualIdx + 1}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleNext}
          disabled={idx === order.length - 1}
          style={{
            padding: '8px 16px',
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'transparent',
            color: idx === order.length - 1 ? 'var(--text3)' : 'var(--text2)',
            fontSize: 13,
            cursor: idx === order.length - 1 ? 'default' : 'pointer',
            opacity: idx === order.length - 1 ? 0.4 : 1,
          }}
        >
          Keyingi →
        </button>
      </div>

      {/* Question card */}
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        padding: '28px',
        marginBottom: 16,
      }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 20 }}>
          <div style={{
            flexShrink: 0,
            width: 36,
            height: 36,
            borderRadius: 10,
            background: 'var(--gold-dim)',
            border: '1px solid rgba(232,184,75,0.25)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 700,
            color: 'var(--gold)',
            fontSize: 13,
          }}>
            {q.number}
          </div>
          <p style={{ fontSize: 16, lineHeight: 1.6, color: 'var(--text)', paddingTop: 8 }}>
            {q.question}
          </p>
        </div>

        {/* Options hint (hidden until revealed) */}
        {settings.showHints && !revealed && (
          <div style={{ marginBottom: 16, padding: '10px 14px', background: 'var(--bg3)', borderRadius: 8 }}>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Variant soni: {q.options.length}
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {q.options.map((_, i) => (
                <span key={i} style={{
                  padding: '2px 8px',
                  borderRadius: 4,
                  background: 'var(--bg4)',
                  color: 'var(--text3)',
                  fontSize: 11,
                  fontWeight: 600,
                }}>
                  {OPTION_LABELS[i]}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Text area */}
        <textarea
          ref={textareaRef}
          value={userText}
          onChange={e => setUserText(e.target.value)}
          placeholder={revealed ? '' : "Javobingizni shu yerga yozing..."}
          disabled={revealed}
          rows={4}
          onKeyDown={e => {
            if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); if (!revealed) handleCheck(); }
          }}
          style={{
            width: '100%',
            padding: '14px',
            background: 'var(--bg3)',
            border: `1px solid ${revealed ? (isGood ? 'rgba(74,222,128,0.3)' : 'rgba(248,113,113,0.3)') : 'var(--border)'}`,
            borderRadius: 10,
            color: 'var(--text)',
            fontSize: 14,
            lineHeight: 1.6,
            resize: 'vertical',
            outline: 'none',
            transition: 'border 0.2s',
          }}
          onFocus={e => { if (!revealed) e.target.style.borderColor = 'var(--gold)'; }}
          onBlur={e => { if (!revealed) e.target.style.borderColor = 'var(--border)'; }}
        />

        <div style={{ display: 'flex', gap: 10, marginTop: 12, alignItems: 'center' }}>
          {!revealed ? (
            <button
              onClick={handleCheck}
              disabled={!userText.trim()}
              style={{
                padding: '11px 28px',
                borderRadius: 8,
                background: userText.trim() ? 'var(--gold)' : 'var(--bg4)',
                color: userText.trim() ? '#0d0f14' : 'var(--text3)',
                fontSize: 14,
                fontWeight: 600,
                cursor: userText.trim() ? 'pointer' : 'default',
                transition: 'all 0.2s',
                border: 'none',
              }}
            >
              Tekshirish
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={idx === order.length - 1}
              style={{
                padding: '11px 28px',
                borderRadius: 8,
                background: 'var(--gold)',
                color: '#0d0f14',
                fontSize: 14,
                fontWeight: 600,
                cursor: 'pointer',
                border: 'none',
              }}
            >
              Keyingi savol →
            </button>
          )}
          <span style={{ fontSize: 12, color: 'var(--text3)' }}>Ctrl+Enter</span>
        </div>
      </div>

      {/* Result */}
      {revealed && result && (
        <div
          ref={resultRef}
          style={{
            background: 'var(--surface)',
            border: `1px solid ${isGood ? 'rgba(74,222,128,0.2)' : 'rgba(248,113,113,0.2)'}`,
            borderRadius: 'var(--radius-lg)',
            padding: '24px 28px',
            animation: 'scaleIn 0.3s ease',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
            <div style={{
              width: 72,
              height: 72,
              borderRadius: 16,
              background: `${scoreColor}22`,
              border: `2px solid ${scoreColor}`,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: scoreColor, lineHeight: 1 }}>
                {result.score}%
              </div>
              <div style={{ fontSize: 11, color: scoreColor, fontWeight: 600 }}>{result.grade}</div>
            </div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: scoreColor, marginBottom: 4 }}>
                {gradeLabel(result.score)}
              </div>
              {result.feedback.map((f, i) => (
                <div key={i} style={{ fontSize: 13, color: 'var(--text2)' }}>• {f}</div>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
              To'g'ri javob
            </div>
            <div style={{
              padding: '14px 16px',
              background: 'var(--green-bg)',
              border: '1px solid rgba(74,222,128,0.2)',
              borderRadius: 8,
              fontSize: 14,
              lineHeight: 1.6,
              color: 'var(--text)',
            }}>
              <span style={{ color: 'var(--green)', fontWeight: 700, marginRight: 8 }}>
                {OPTION_LABELS[q.correctIndex]})
              </span>
              {correctAnswer}
            </div>
          </div>

          {/* Score bars */}
          {result.details && (
            <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[
                { label: 'So\'z mos.', val: result.details.jaccard },
                { label: 'Semantik', val: result.details.cosine },
                { label: 'Kalit s\'z', val: result.details.coverage },
                { label: 'Matn', val: result.details.lcs },
              ].map(({ label, val }) => (
                <div key={label}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text3)', marginBottom: 3 }}>
                    <span>{label}</span><span>{Math.round(val * 100)}%</span>
                  </div>
                  <div style={{ height: 3, background: 'var(--bg4)', borderRadius: 2 }}>
                    <div style={{
                      height: '100%',
                      width: `${val * 100}%`,
                      background: val > 0.6 ? 'var(--green)' : val > 0.35 ? 'var(--amber)' : 'var(--red)',
                      borderRadius: 2,
                      transition: 'width 0.6s ease',
                    }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
