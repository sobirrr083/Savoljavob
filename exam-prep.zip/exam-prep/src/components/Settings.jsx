import { useState } from 'react';

const overlay = {
  position: 'fixed', inset: 0,
  background: 'rgba(0,0,0,0.6)',
  backdropFilter: 'blur(4px)',
  zIndex: 100,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  padding: 20,
};

const panel = {
  background: 'var(--bg2)',
  border: '1px solid var(--border2)',
  borderRadius: 'var(--radius-lg)',
  padding: '28px',
  width: '100%',
  maxWidth: 440,
  animation: 'scaleIn 0.2s ease',
  boxShadow: 'var(--shadow-lg)',
};

function Toggle({ value, onChange, label, desc }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 0', borderBottom: '1px solid var(--border)',
      gap: 12,
    }}>
      <div>
        <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text)', marginBottom: 2 }}>{label}</div>
        {desc && <div style={{ fontSize: 12, color: 'var(--text3)' }}>{desc}</div>}
      </div>
      <button
        onClick={() => onChange(!value)}
        style={{
          width: 44, height: 24, borderRadius: 12, position: 'relative',
          background: value ? 'var(--gold)' : 'var(--bg4)',
          border: 'none', cursor: 'pointer',
          transition: 'background 0.2s', flexShrink: 0,
        }}
      >
        <div style={{
          position: 'absolute',
          top: 3, left: value ? 23 : 3,
          width: 18, height: 18,
          borderRadius: '50%',
          background: value ? '#0d0f14' : 'var(--text3)',
          transition: 'left 0.2s',
        }} />
      </button>
    </div>
  );
}

export default function Settings({ settings, onChange, onClose }) {
  const [local, setLocal] = useState({ ...settings });

  const set = (key, val) => setLocal(prev => ({ ...prev, [key]: val }));

  const handleSave = () => {
    onChange(local);
    onClose();
  };

  return (
    <div style={overlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={panel}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700 }}>
            ⚙️ Sozlamalar
          </h2>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, borderRadius: 8,
              background: 'var(--bg3)', border: '1px solid var(--border)',
              color: 'var(--text2)', fontSize: 16, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >✕</button>
        </div>

        {/* Per ticket slider */}
        <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text)', marginBottom: 2 }}>
                Biletdagi savollar soni
              </div>
              <div style={{ fontSize: 12, color: 'var(--text3)' }}>
                Bilet rejimida har bir biletdagi savollar
              </div>
            </div>
            <div style={{
              background: 'var(--gold-dim)', border: '1px solid rgba(232,184,75,0.25)',
              borderRadius: 8, padding: '4px 12px',
              fontSize: 16, fontWeight: 700, color: 'var(--gold)',
            }}>
              {local.perTicket}
            </div>
          </div>
          <input
            type="range"
            min={5} max={30} step={5}
            value={local.perTicket}
            onChange={e => set('perTicket', parseInt(e.target.value))}
            style={{
              width: '100%', height: 4, borderRadius: 2,
              background: `linear-gradient(90deg, var(--gold) ${((local.perTicket - 5) / 25) * 100}%, var(--bg4) 0%)`,
              outline: 'none', appearance: 'none', cursor: 'pointer',
              WebkitAppearance: 'none',
            }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>
            <span>5</span><span>10</span><span>15</span><span>20</span><span>25</span><span>30</span>
          </div>
        </div>

        <Toggle
          value={local.shuffleQuestions}
          onChange={v => set('shuffleQuestions', v)}
          label="Savollarni aralashtirish"
          desc="Har safar savollar tartibini o'zgartiradi"
        />
        <Toggle
          value={local.shuffleOptions}
          onChange={v => set('shuffleOptions', v)}
          label="Variantlarni aralashtirish"
          desc="A/B/C/D tartibini tasodifiy qiladi"
        />
        <Toggle
          value={local.showHints}
          onChange={v => set('showHints', v)}
          label="Ko'rsatmalar"
          desc="Yozma rejimda variant soni ko'rsatiladi"
        />

        <div style={{ marginTop: 24, display: 'flex', gap: 10 }}>
          <button
            onClick={handleSave}
            style={{
              flex: 1, padding: '12px',
              borderRadius: 8, background: 'var(--gold)',
              color: '#0d0f14', fontSize: 14, fontWeight: 600,
              cursor: 'pointer', border: 'none',
            }}
          >
            Saqlash
          </button>
          <button
            onClick={onClose}
            style={{
              padding: '12px 20px', borderRadius: 8,
              border: '1px solid var(--border)', background: 'transparent',
              color: 'var(--text2)', fontSize: 14, cursor: 'pointer',
            }}
          >
            Bekor
          </button>
        </div>
      </div>
    </div>
  );
}
