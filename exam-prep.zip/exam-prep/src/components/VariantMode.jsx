import { useState, useMemo, useEffect } from 'react';
import { shuffleArray, shuffleOptions } from '../utils/parser.js';

const OPTION_LABELS = ['A', 'B', 'C', 'D', 'E', 'F'];
const OPTION_COLORS = ['#60a5fa', '#4ade80', '#fb923c', '#c084fc', '#22d3ee', '#fb7185'];

export default function VariantMode({ questions, settings }) {
  const [order, setOrder] = useState(() =>
    settings.shuffleQuestions ? shuffleArray(questions.map((_, i) => i)) : questions.map((_, i) => i)
  );
  const [displayQs, setDisplayQs] = useState(() =>
    settings.shuffleOptions ? questions.map(q => shuffleOptions(q)) : questions
  );
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState({});
  const [showExpl, setShowExpl] = useState(false);

  const q = useMemo(() => displayQs[order[idx]], [displayQs, order, idx]);

  useEffect(() => {
    const prev = answered[order[idx]];
    setSelected(prev?.selected ?? null);
    setShowExpl(prev !== undefined);
  }, [idx, order, answered]);

  const handleSelect = (i) => {
    if (selected !== null) return;
    setSelected(i);
    const correct = i === q.correctIndex;
    setAnswered(prev => ({
      ...prev,
      [order[idx]]: { selected: i, correct },
    }));
    setShowExpl(true);
  };

  const handleNext = () => {
    if (idx < order.length - 1) setIdx(i => i + 1);
  };

  const handlePrev = () => {
    if (idx > 0) setIdx(i => i - 1);
  };

  const handleReshuffle = () => {
    const newOrder = shuffleArray(questions.map((_, i) => i));
    setOrder(newOrder);
    setDisplayQs(settings.shuffleOptions ? questions.map(q => shuffleOptions(q)) : questions);
    setIdx(0);
    setAnswered({});
    setSelected(null);
    setShowExpl(false);
  };

  const correct = Object.values(answered).filter(a => a.correct).length;
  const total = Object.keys(answered).length;
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : null;

  if (!q) return null;

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, gap: 16 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, marginBottom: 4 }}>
            Variant Rejimi
          </h1>
          <div style={{ display: 'flex', gap: 16, fontSize: 13 }}>
            <span style={{ color: 'var(--text2)' }}>{total}/{questions.length} javob</span>
            {accuracy !== null && (
              <>
                <span style={{ color: 'var(--green)' }}>✓ {correct} to'g'ri</span>
                <span style={{ color: 'var(--red)' }}>✗ {total - correct} noto'g'ri</span>
                <span style={{ color: 'var(--gold)' }}>{accuracy}%</span>
              </>
            )}
          </div>
        </div>
        <button
          onClick={handleReshuffle}
          style={{
            padding: '8px 14px',
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'transparent',
            color: 'var(--text2)',
            fontSize: 12,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}
        >
          🔀 Aralashtirish
        </button>
      </div>

      {/* Progress */}
      <div style={{ height: 4, background: 'var(--surface)', borderRadius: 2, marginBottom: 24, overflow: 'hidden' }}>
        <div style={{
          height: '100%',
          background: `linear-gradient(90deg, var(--gold), var(--gold2))`,
          width: `${(idx / (order.length - 1)) * 100}%`,
          borderRadius: 2,
          transition: 'width 0.3s ease',
        }} />
      </div>

      {/* Question number pills */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 24, flexWrap: 'wrap' }}>
        {order.map((qi, i) => {
          const ans = answered[qi];
          const isCurrent = i === idx;
          let bg = 'var(--bg3)';
          let color = 'var(--text3)';
          let border = 'transparent';
          if (isCurrent) { bg = 'var(--gold)'; color = '#0d0f14'; border = 'var(--gold)'; }
          else if (ans?.correct) { bg = 'var(--green-bg)'; color = 'var(--green)'; border = 'rgba(74,222,128,0.3)'; }
          else if (ans && !ans.correct) { bg = 'var(--red-bg)'; color = 'var(--red)'; border = 'rgba(248,113,113,0.3)'; }
          return (
            <button
              key={qi}
              onClick={() => setIdx(i)}
              style={{
                width: 30,
                height: 30,
                borderRadius: 7,
                fontSize: 11,
                fontWeight: 600,
                background: bg,
                color,
                border: `1px solid ${border}`,
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              {questions[qi]?.number || i + 1}
            </button>
          );
        })}
      </div>

      {/* Question card */}
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        padding: '28px',
        marginBottom: 16,
        animation: 'scaleIn 0.25s ease',
        key: order[idx],
      }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
          <div style={{
            flexShrink: 0, width: 36, height: 36, borderRadius: 10,
            background: 'var(--gold-dim)', border: '1px solid rgba(232,184,75,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, color: 'var(--gold)', fontSize: 13,
          }}>
            {q.number}
          </div>
          <p style={{ fontSize: 16, lineHeight: 1.6, paddingTop: 8, flex: 1 }}>{q.question}</p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {q.options.map((opt, i) => {
            const isSelected = selected === i;
            const isCorrect = i === q.correctIndex;
            const hasAnswered = selected !== null;

            let bg = 'var(--bg3)';
            let border = 'var(--border)';
            let labelBg = 'var(--bg4)';
            let labelColor = 'var(--text2)';
            let textColor = 'var(--text2)';
            let scale = '1';

            if (hasAnswered) {
              if (isCorrect) {
                bg = 'var(--green-bg)'; border = 'rgba(74,222,128,0.3)';
                labelBg = 'var(--green)'; labelColor = '#0d0f14'; textColor = 'var(--text)';
              } else if (isSelected && !isCorrect) {
                bg = 'var(--red-bg)'; border = 'rgba(248,113,113,0.3)';
                labelBg = 'var(--red)'; labelColor = '#fff'; textColor = 'var(--text)';
              }
            } else {
              labelColor = OPTION_COLORS[i] || 'var(--text2)';
            }

            return (
              <button
                key={i}
                onClick={() => handleSelect(i)}
                disabled={hasAnswered}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: 12,
                  padding: '12px 16px',
                  borderRadius: 10,
                  background: bg,
                  border: `1px solid ${border}`,
                  cursor: hasAnswered ? 'default' : 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.18s',
                  transform: scale === '1' ? 'none' : `scale(${scale})`,
                }}
                onMouseEnter={e => { if (!hasAnswered) e.currentTarget.style.borderColor = OPTION_COLORS[i]; }}
                onMouseLeave={e => { if (!hasAnswered) e.currentTarget.style.borderColor = 'var(--border)'; }}
              >
                <span style={{
                  flexShrink: 0, width: 28, height: 28, borderRadius: 7,
                  background: labelBg, color: labelColor,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700, transition: 'all 0.18s',
                }}>
                  {OPTION_LABELS[i]}
                </span>
                <span style={{ fontSize: 14, color: textColor, lineHeight: 1.55, paddingTop: 5, flex: 1 }}>
                  {opt}
                </span>
                {hasAnswered && isCorrect && (
                  <span style={{ color: 'var(--green)', fontSize: 16, flexShrink: 0, paddingTop: 4 }}>✓</span>
                )}
                {hasAnswered && isSelected && !isCorrect && (
                  <span style={{ color: 'var(--red)', fontSize: 16, flexShrink: 0, paddingTop: 4 }}>✗</span>
                )}
              </button>
            );
          })}
        </div>

        {showExpl && (
          <div style={{
            marginTop: 16,
            padding: '12px 16px',
            borderRadius: 8,
            background: answered[order[idx]]?.correct ? 'var(--green-bg)' : 'var(--red-bg)',
            border: `1px solid ${answered[order[idx]]?.correct ? 'rgba(74,222,128,0.2)' : 'rgba(248,113,113,0.2)'}`,
            fontSize: 13,
            color: answered[order[idx]]?.correct ? 'var(--green)' : 'var(--red)',
            animation: 'fadeIn 0.2s ease',
          }}>
            {answered[order[idx]]?.correct
              ? "✓ Ajoyib! To'g'ri javob."
              : `✗ Noto'g'ri. To'g'ri javob: ${OPTION_LABELS[q.correctIndex]}) ${q.options[q.correctIndex]}`}
          </div>
        )}
      </div>

      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
        <button
          onClick={handlePrev}
          disabled={idx === 0}
          style={{
            padding: '11px 24px', borderRadius: 8,
            border: '1px solid var(--border)', background: 'transparent',
            color: 'var(--text2)', fontSize: 14, cursor: idx === 0 ? 'default' : 'pointer',
            opacity: idx === 0 ? 0.4 : 1,
          }}
        >← Oldingi</button>

        <button
          onClick={handleNext}
          disabled={idx === order.length - 1}
          style={{
            padding: '11px 24px', borderRadius: 8,
            background: idx === order.length - 1 ? 'var(--bg3)' : 'var(--gold)',
            color: idx === order.length - 1 ? 'var(--text3)' : '#0d0f14',
            fontSize: 14, fontWeight: 600,
            cursor: idx === order.length - 1 ? 'default' : 'pointer',
            border: 'none',
          }}
        >Keyingi →</button>
      </div>
    </div>
  );
}
