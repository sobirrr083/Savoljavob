import { useState, useRef, useCallback } from 'react';

const s = {
  root: {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'var(--bg)',
    padding: '40px 20px',
    position: 'relative',
    overflow: 'hidden',
  },
  glow: {
    position: 'absolute',
    borderRadius: '50%',
    filter: 'blur(80px)',
    pointerEvents: 'none',
    zIndex: 0,
  },
  content: {
    position: 'relative',
    zIndex: 1,
    textAlign: 'center',
    maxWidth: 560,
    width: '100%',
  },
  badge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    background: 'var(--gold-dim)',
    border: '1px solid rgba(232,184,75,0.25)',
    borderRadius: 100,
    padding: '4px 14px',
    fontSize: 12,
    color: 'var(--gold)',
    fontWeight: 500,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    marginBottom: 24,
  },
  heading: {
    fontFamily: 'var(--font-display)',
    fontSize: 'clamp(36px, 6vw, 56px)',
    fontWeight: 700,
    lineHeight: 1.1,
    marginBottom: 16,
    color: 'var(--text)',
  },
  accent: { color: 'var(--gold)', fontStyle: 'italic' },
  sub: {
    color: 'var(--text2)',
    fontSize: 16,
    lineHeight: 1.6,
    marginBottom: 48,
    maxWidth: 420,
    margin: '0 auto 48px',
  },
  dropzone: {
    border: '2px dashed var(--border2)',
    borderRadius: 'var(--radius-lg)',
    padding: '48px 32px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    background: 'var(--surface)',
    position: 'relative',
    overflow: 'hidden',
  },
  dropzoneActive: {
    border: '2px dashed var(--gold)',
    background: 'var(--gold-dim)',
    transform: 'scale(1.01)',
  },
  dropIcon: {
    width: 64,
    height: 64,
    margin: '0 auto 20px',
    background: 'var(--gold-dim)',
    borderRadius: 16,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 28,
  },
  dropTitle: {
    fontSize: 18,
    fontWeight: 600,
    color: 'var(--text)',
    marginBottom: 8,
  },
  dropSub: { color: 'var(--text2)', fontSize: 14, marginBottom: 20 },
  btn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    background: 'var(--gold)',
    color: '#0d0f14',
    padding: '10px 24px',
    borderRadius: 8,
    fontSize: 14,
    fontWeight: 600,
    transition: 'all 0.2s',
    cursor: 'pointer',
    border: 'none',
  },
  features: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: 12,
    marginTop: 32,
    textAlign: 'left',
  },
  feat: {
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 10,
    padding: '14px 16px',
    display: 'flex',
    gap: 10,
    alignItems: 'flex-start',
  },
  featIcon: { fontSize: 20, flexShrink: 0, marginTop: 1 },
  featTitle: { fontSize: 13, fontWeight: 600, color: 'var(--text)', marginBottom: 2 },
  featDesc: { fontSize: 12, color: 'var(--text3)', lineHeight: 1.4 },
};

const FEATURES = [
  { icon: '📖', title: "Erkin o'qish", desc: "Barcha savol-javoblarni ko'rib chiqing" },
  { icon: '✍️', title: "Yozma javob", desc: "Yozing va to'g'riligi baholansin" },
  { icon: '📋', title: "Variant uslubi", desc: "A/B/C/D tanlov bilan ishlang" },
  { icon: '🎫', title: "Bilet rejimi", desc: "Random biletlar bilan imtihon" },
];

export default function FileUpload({ onFile }) {
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef();

  const read = useCallback((file) => {
    if (!file) return;
    if (!file.name.endsWith('.txt')) {
      setError("Faqat .txt fayl qabul qilinadi");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      if (!text.trim()) { setError("Fayl bo'sh"); return; }
      onFile(text, file.name);
    };
    reader.readAsText(file, 'UTF-8');
  }, [onFile]);

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    setError('');
    read(e.dataTransfer.files[0]);
  }, [read]);

  const onDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);
  const onInput = (e) => { setError(''); read(e.target.files[0]); e.target.value = ''; };

  return (
    <div style={s.root}>
      {/* Background glows */}
      <div style={{ ...s.glow, width:400, height:400, top:-100, right:-100, background:'rgba(232,184,75,0.06)' }} />
      <div style={{ ...s.glow, width:500, height:500, bottom:-150, left:-150, background:'rgba(96,165,250,0.04)' }} />

      <div style={s.content} className="fade-in">
        <div style={s.badge}>
          <span>★</span> ImtihonPro
        </div>

        <h1 style={s.heading}>
          Samarali <span style={s.accent}>tayyorlanish</span><br />platformasi
        </h1>

        <p style={s.sub}>
          .txt formatidagi test faylingizni yuklang va 4 xil rejimda tayyorlanishni boshlang
        </p>

        <div
          style={{ ...s.dropzone, ...(dragging ? s.dropzoneActive : {}) }}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onClick={() => inputRef.current?.click()}
        >
          <div style={s.dropIcon}>📄</div>
          <div style={s.dropTitle}>
            {dragging ? 'Qo\'yib yuboring...' : 'Faylingizni bu yerga tashlang'}
          </div>
          <div style={s.dropSub}>yoki</div>
          <button
            style={s.btn}
            onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}
            onMouseEnter={e => e.currentTarget.style.filter = 'brightness(1.1)'}
            onMouseLeave={e => e.currentTarget.style.filter = ''}
          >
            📂 Fayl tanlash (.txt)
          </button>
          {error && (
            <div style={{ marginTop: 12, color: 'var(--red)', fontSize: 13 }}>⚠ {error}</div>
          )}
        </div>

        <div style={s.features}>
          {FEATURES.map(f => (
            <div key={f.title} style={s.feat}>
              <span style={s.featIcon}>{f.icon}</span>
              <div>
                <div style={s.featTitle}>{f.title}</div>
                <div style={s.featDesc}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept=".txt"
        style={{ display: 'none' }}
        onChange={onInput}
      />
    </div>
  );
}
